    
    <!-- Logo Header -->
    
    <!-- End Logo Header -->
    
    <!-- Navbar Header -->
    
    <!-- End Navbar -->
    



    <!-- HEADER -->
    <header class="fixed top-0 left-0 right-0 h-20 bg-white shadow flex items-center justify-between px-6 z-40">
        <div class="flex items-center space-x-4">
            <svg viewBox="0 0 576 512" fill="#d4af37" class="h-10 w-10">
                <path
                    d="M485.5 0L576 160H474.9L405.7 0h79.8zm-128 0l69.2 160H149.3L218.5 0h139zm-267 0h79.8l-69.2 160H0L90.5 0zM0 192h100.7l123 251.7c1.5 3.1-2.7 5.9-5 3.3L0 192zm148.2 0h279.6l-137 318.2c-1 2.4-4.5 2.4-5.5 0L148.2 192zm204.1 251.7l123-251.7H576L357.3 446.9c-2.3 2.7-6.5-.1-5-3.2z">
                </path>
            </svg>
            <span class="ml-2 text-3xl font-normal font-aleo text-black">DexGems DMCC</span>
        </div>
        <div class="flex-1 flex items-center justify-center">
            <span class="font-bold text-gray-700 text-xl font-aleo">Welcome, Admin</span>
        </div>
        <div class="flex items-center space-x-4">
            <button class="relative focus:outline-none">
                <i class="fa fa-bell-o w-6 h-6"></i>

                <span class="absolute top-0 right-0 block h-2 w-2 bg-red-500 rounded-full ring-2 ring-white"></span>
            </button>
            <img src="https://randomuser.me/api/portraits/men/44.jpg" alt="Profile"
                class="h-10 w-10 rounded-full border-2 border-brand-gold">
            <button id="sidebar-toggle"
                class="lg:hidden ml-2 p-2 rounded hover:bg-gray-100 focus:outline-none transition">
                <i data-lucide="menu" class="w-7 h-7 text-gray-500"></i>
            </button>
        </div>
    </header>
<?php /**PATH F:\DiamondAuctionBackend\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>