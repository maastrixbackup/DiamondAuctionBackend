<?php $__env->startSection('title', 'Lot List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-lg-4 pt-lg-4">
        <div class="page-inner">
            <div class="page-header d-flex align-items-center justify-content-between flex-wrap mb-3">
                <div class="d-flex align-items-center gap-3">
                    <h3 class="fw-bold mb-0">Lots</h3>
                    <ul class="breadcrumbs d-flex align-items-center mb-0">
                        <li class="nav-home me-2">
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <li class="separator me-2">
                            <i class="icon-arrow-right"></i>
                        </li>
                        <li class="nav-item">
                            <a href="#">Lots</a>
                        </li>
                    </ul>
                </div>
            </div>


            <div class="row">
                <div class="col-md-12">
                    <form method="GET" action="<?php echo e(route('admin.lots.index')); ?>" class="mb-3">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-3">
                                <label for="status" class="form-label">Status</label>
                                <select name="status" id="status" class="form-control">
                                    <option value="">-- All --</option>
                                    <option value="0" <?php echo e(request('status') == '0' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Active</option>
                                    <option value="2" <?php echo e(request('status') == '2' ? 'selected' : ''); ?>>Sold</option>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="type" class="form-label">Type</label>
                                <input type="text" name="type" id="type" value="<?php echo e(request('type')); ?>"
                                    class="form-control" placeholder="Search Type">
                            </div>

                            <div class="col-md-3">
                                <label for="weight" class="form-label">Weight</label>
                                <input type="text" name="weight" id="weight" value="<?php echo e(request('weight')); ?>"
                                    class="form-control" placeholder="Search Weight">
                            </div>

                            <div class="col-md-3 d-flex gap-2">
                                <button type="submit" class="btn btn-primary w-100">Search</button>
                                <a href="<?php echo e(route('admin.lots.index')); ?>" class="btn btn-secondary w-100">Reset</a>
                            </div>
                        </div>
                    </form>

                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h4 class="card-title mb-0">All Lots</h4>
                            <a href="<?php echo e(route('admin.lots.create')); ?>" class="btn btn-primary" title="Add Lot">
                                + Add
                            </a>
                        </div>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" id="success-alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Seller</th>
                                            <th>Type</th>
                                            <th>Weight</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                
                                                <td><?php echo e($lot->seller ? $lot->seller->full_name : 'N/A'); ?></td>
                                                <td><?php echo e($lot->type); ?></td>
                                                <td><?php echo e($lot->weight); ?></td>
                                                <td>
                                                    <?php if($lot->status == 0): ?>
                                                        <span class="badge bg-danger">Pending</span>
                                                    <?php elseif($lot->status == 1): ?>
                                                        <span class="badge bg-success">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">Sold</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.lots.edit', $lot->id)); ?>"
                                                        class="btn btn-sm btn-info" title="Edit"><i
                                                            class="icon-pencil"></i></a>
                                                    <a href="<?php echo e(route('admin.lots.show', $lot->id)); ?>"
                                                        class="btn btn-sm btn-primary" title="View">
                                                        <i class="icon-eye"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('admin.lots.destroy', $lot->id)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-sm btn-danger" title="Delete"
                                                            onclick="return confirm('Are you sure to delete this?')"><i
                                                                class="icon-trash"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        window.onload = function() {
            let alert = document.getElementById('success-alert');
            if (alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500); // remove after fade out
                }, 3000); // 3 seconds
            }
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\diamond_auction\resources\views/admin/lots/list.blade.php ENDPATH**/ ?>