<?php $__env->startSection('title', 'View Seller'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-lg-4 pt-lg-4">
        <div class="page-inner">
            <div class="page-header d-flex align-items-center justify-content-between flex-wrap mb-3">
                <div class="d-flex align-items-center gap-3">
                    <h3 class="fw-bold mb-0">Seller Details</h3>
                    <ul class="breadcrumbs d-flex align-items-center mb-0">
                        <li class="nav-home me-2">
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <li class="separator me-2">
                            <i class="icon-arrow-right"></i>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.seller')); ?>">Sellers</a>
                        </li>
                        <li class="separator"><i class="icon-arrow-right"></i></li>
                        <li class="nav-item">View Seller</li>
                    </ul>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Seller Details</h4>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div id="success-alert" class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th>Type</th>
                                <td><?php echo e($seller->type == 1 ? 'Company' : 'Individual'); ?></td>
                            </tr>
                            <tr>
                                <th>Full Name</th>
                                <td><?php echo e($seller->full_name); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($seller->email_address); ?></td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td><?php echo e($seller->phone_number); ?></td>
                            </tr>
                            <tr>
                                <th>Country</th>
                                <td><?php echo e($seller->country); ?></td>
                            </tr>

                            <?php if($seller->type == 1): ?>
                                
                                <tr>
                                    <th>Company Name</th>
                                    <td><?php echo e($seller->company_name); ?></td>
                                </tr>
                                <tr>
                                    <th>Registration Number</th>
                                    <td><?php echo e($seller->registration_number); ?></td>
                                </tr>
                                <tr>
                                    <th>Director Name</th>
                                    <td><?php echo e($seller->director_name); ?></td>
                                </tr>
                                <tr>
                                    <th>Director Email</th>
                                    <td><?php echo e($seller->director_email); ?></td>
                                </tr>
                                <tr>
                                    <th>Director Phone</th>
                                    <td><?php echo e($seller->director_phone); ?></td>
                                </tr>

                                
                                

                                <tr>
                                    <th>Certificate of Incorporation</th>
                                    <td>
                                        <?php if($seller->certificate_of_incorporation): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->certificate_of_incorporation)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary"
                                                title="View Document">View</a>

                                            <?php if($seller->certificate_of_incorporation_status === 0): ?>
                                                <form action="<?php echo e(route('admin.update-seller-document-status')); ?>" method="POST"
                                                    style="display:inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                                                    <input type="hidden" name="field"
                                                        value="certificate_of_incorporation">
                                                    <button name="status" value="1"
                                                        class="btn btn-sm btn-success">Approve</button>
                                                    <button name="status" value="2"
                                                        class="btn btn-sm btn-danger">Reject</button>
                                                </form>
                                            <?php elseif($seller->certificate_of_incorporation_status == 1): ?>
                                                <span class="badge bg-success ms-2">Approved</span>
                                            <?php elseif($seller->certificate_of_incorporation_status == 2): ?>
                                                <span class="badge bg-danger ms-2">Rejected</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Valid Trade License</th>
                                    <td>
                                        <?php if($seller->valid_trade_license): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->valid_trade_license)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary"
                                                title="View Document">View</a>

                                            <?php if($seller->valid_trade_license_status === 0): ?>
                                                <form action="<?php echo e(route('admin.update-seller-document-status')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                                                    <input type="hidden" name="field" value="valid_trade_license">
                                                    <button type="submit" name="status" value="1"
                                                        class="btn btn-sm btn-success">Approve</button>
                                                    <button type="submit" name="status" value="2"
                                                        class="btn btn-sm btn-danger">Reject</button>
                                                </form>
                                            <?php elseif($seller->valid_trade_license_status === 1): ?>
                                                <span class="badge bg-success ms-2">Approved</span>
                                            <?php elseif($seller->valid_trade_license_status === 2): ?>
                                                <span class="badge bg-danger ms-2">Rejected</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Passport Copy (Authorised)</th>
                                    <td>
                                        <?php if($seller->passport_copy_authorised): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->passport_copy_authorised)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary"
                                                title="View Document">View</a>

                                            <?php if($seller->passport_copy_authorised_status === 0): ?>
                                                <form action="<?php echo e(route('admin.update-seller-document-status')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                                                    <input type="hidden" name="field" value="passport_copy_authorised">
                                                    <button type="submit" name="status" value="1"
                                                        class="btn btn-sm btn-success">Approve</button>
                                                    <button type="submit" name="status" value="2"
                                                        class="btn btn-sm btn-danger">Reject</button>
                                                </form>
                                            <?php elseif($seller->passport_copy_authorised_status === 1): ?>
                                                <span class="badge bg-success ms-2">Approved</span>
                                            <?php elseif($seller->passport_copy_authorised_status === 2): ?>
                                                <span class="badge bg-danger ms-2">Rejected</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>UBO Declaration</th>
                                    <td>
                                        <?php if($seller->ubo_declaration): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->ubo_declaration)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary"
                                                title="View Document">View</a>

                                            <?php if($seller->ubo_declaration_status === 0): ?>
                                                <form action="<?php echo e(route('admin.update-seller-document-status')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                                                    <input type="hidden" name="field" value="ubo_declaration">
                                                    <button type="submit" name="status" value="1"
                                                        class="btn btn-sm btn-success">Approve</button>
                                                    <button type="submit" name="status" value="2"
                                                        class="btn btn-sm btn-danger">Reject</button>
                                                </form>
                                            <?php elseif($seller->ubo_declaration_status === 1): ?>
                                                <span class="badge bg-success ms-2">Approved</span>
                                            <?php elseif($seller->ubo_declaration_status === 2): ?>
                                                <span class="badge bg-danger ms-2">Rejected</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php elseif($seller->type == 2): ?>
                                
                                <tr>
                                    <th>Passport Copy</th>
                                    <td>
                                        <?php if($seller->passport_copy): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->passport_copy)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="View Document"
                                                title="View Document">View</a>

                                            <?php if($seller->passport_copy_status === 0): ?>
                                                <form action="<?php echo e(route('admin.update-seller-document-status')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                                                    <input type="hidden" name="field" value="passport_copy">
                                                    <button type="submit" name="status" value="1"
                                                        class="btn btn-sm btn-success">Approve</button>
                                                    <button type="submit" name="status" value="2"
                                                        class="btn btn-sm btn-danger">Reject</button>
                                                </form>
                                            <?php elseif($seller->passport_copy_status === 1): ?>
                                                <span class="badge bg-success ms-2">Approved</span>
                                            <?php elseif($seller->passport_copy_status === 2): ?>
                                                <span class="badge bg-danger ms-2">Rejected</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <tr>
                                    <th>Proof of Ownership</th>
                                    <td>
                                        <?php if($seller->proof_of_ownership): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->proof_of_ownership)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="View Document"
                                                title="View Document">View</a>

                                            <?php if($seller->proof_of_ownership_status === 0): ?>
                                                <form action="<?php echo e(route('admin.update-seller-document-status')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="seller_id" value="<?php echo e($seller->id); ?>">
                                                    <input type="hidden" name="field" value="proof_of_ownership">
                                                    <button type="submit" name="status" value="1"
                                                        class="btn btn-sm btn-success">Approve</button>
                                                    <button type="submit" name="status" value="2"
                                                        class="btn btn-sm btn-danger">Reject</button>
                                                </form>
                                            <?php elseif($seller->proof_of_ownership_status === 1): ?>
                                                <span class="badge bg-success ms-2">Approved</span>
                                            <?php elseif($seller->proof_of_ownership_status === 2): ?>
                                                <span class="badge bg-danger ms-2">Rejected</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <th>KYC Status</th>
                                <td>
                                    <?php if($seller->kyc_status == 0): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($seller->kyc_status == 1): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php elseif($seller->kyc_status == 2): ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Account Status</th>
                                <td>
                                    
                                    <?php if($seller->account_status == 0): ?>
                                        <span class="badge bg-warning ms-2">Pending</span>
                                    <?php elseif($seller->account_status == 1): ?>
                                        <span class="badge bg-success ms-2">Active</span>
                                    <?php elseif($seller->account_status == 2): ?>
                                        <span class="badge bg-danger ms-2">Suspended</span>
                                    <?php endif; ?>

                                    
                                    <span class="ms-3">
                                        <?php if($seller->account_status !== 1): ?>
                                            <a href="<?php echo e(route('admin.change-seller-account-status', ['id' => $seller->id, 'status' => 1])); ?>"
                                                class="btn btn-sm btn-success">Set Active</a>
                                        <?php endif; ?>

                                        <?php if($seller->account_status !== 2): ?>
                                            <a href="<?php echo e(route('admin.change-seller-account-status', ['id' => $seller->id, 'status' => 2])); ?>"
                                                class="btn btn-sm btn-danger">Set Suspended</a>
                                        <?php endif; ?>
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <a href="<?php echo e(route('admin.seller')); ?>" class="btn btn-secondary mt-3">Back to List</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.onload = function() {
            const alert = document.getElementById('success-alert');
            if (alert) {
                setTimeout(() => {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                }, 3000);
            }
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\DiamondAuctionBackend\resources\views/admin/seller/seller_details.blade.php ENDPATH**/ ?>