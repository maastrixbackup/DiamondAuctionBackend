<?php $__env->startSection('title', 'View Seller'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-lg-4 pt-lg-4">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Seller Details</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator"><i class="icon-arrow-right"></i></li>
                    <li class="nav-item"><a href="<?php echo e(route('admin.seller')); ?>">Sellers</a></li>
                    <li class="separator"><i class="icon-arrow-right"></i></li>
                    <li class="nav-item">View Seller</li>
                </ul>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Seller Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th>Type</th>
                                <td><?php echo e($seller->type == 1 ? 'Company' : 'Individual'); ?></td>
                            </tr>
                            <tr>
                                <th>Full Name</th>
                                <td><?php echo e($seller->full_name); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($seller->email_address); ?></td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td><?php echo e($seller->phone_number); ?></td>
                            </tr>
                            <tr>
                                <th>Country</th>
                                <td><?php echo e($seller->country); ?></td>
                            </tr>

                            <?php if($seller->type == 1): ?>
                                
                                <tr>
                                    <th>Company Name</th>
                                    <td><?php echo e($seller->company_name); ?></td>
                                </tr>
                                <tr>
                                    <th>Registration Number</th>
                                    <td><?php echo e($seller->registration_number); ?></td>
                                </tr>
                                <tr>
                                    <th>Director Name</th>
                                    <td><?php echo e($seller->director_name); ?></td>
                                </tr>
                                <tr>
                                    <th>Director Email</th>
                                    <td><?php echo e($seller->director_email); ?></td>
                                </tr>
                                <tr>
                                    <th>Director Phone</th>
                                    <td><?php echo e($seller->director_phone); ?></td>
                                </tr>

                                
                                <tr>
                                    <th>Certificate of Incorporation</th>
                                    <td>
                                        <?php if($seller->certificate_of_incorporation): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->certificate_of_incorporation)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="Click to view">View
                                                Document</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Valid Trade License</th>
                                    <td>
                                        <?php if($seller->valid_trade_license): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->valid_trade_license)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="Click to view">View
                                                Document</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Passport Copy (Authorised)</th>
                                    <td>
                                        <?php if($seller->passport_copy_authorised): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->passport_copy_authorised)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="Click to view">View
                                                Document</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>UBO Declaration</th>
                                    <td>
                                        <?php if($seller->ubo_declaration): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->ubo_declaration)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="Click to view">View
                                                Document</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php elseif($seller->type == 2): ?>
                                
                                <tr>
                                    <th>Passport Copy</th>
                                    <td>
                                        <?php if($seller->passport_copy): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->passport_copy)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="Click to view">View
                                                Document</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Proof of Address</th>
                                    <td>
                                        <?php if($seller->proof_of_ownership): ?>
                                            <a href="<?php echo e(asset('storage/document/seller/' . $seller->proof_of_ownership)); ?>"
                                                target="_blank" class="btn btn-sm btn-primary" title="Click to view">View
                                                Document</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <th>KYC Status</th>
                                <td>
                                    <?php if($seller->kyc_status == 0): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($seller->kyc_status == 1): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php elseif($seller->kyc_status == 2): ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Account Status</th>
                                <td>
                                    <?php if($seller->account_status == 0): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($seller->account_status == 1): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php elseif($seller->account_status == 2): ?>
                                        <span class="badge bg-danger">Suspended</span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            
                        </tbody>
                    </table>

                    <a href="<?php echo e(route('admin.seller')); ?>" class="btn btn-secondary mt-3">Back to List</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\diamond_auction\resources\views/admin/seller/seller_details.blade.php ENDPATH**/ ?>