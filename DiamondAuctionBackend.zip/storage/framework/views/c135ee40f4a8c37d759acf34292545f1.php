<?php $__env->startSection('title', 'View Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-lg-4 pt-lg-4">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Admin Details</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator"><i class="icon-arrow-right"></i></li>
                    <li class="nav-item"><a href="<?php echo e(route('admin.admin')); ?>">Admins</a></li>
                    <li class="separator"><i class="icon-arrow-right"></i></li>
                    <li class="nav-item">View Admin</li>
                </ul>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Admin Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th>Name</th>
                                <td><?php echo e($admin->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($admin->email); ?></td>
                            </tr>
                            <tr>
                                <th>Role</th>
                                <td><span class="badge bg-info"><?php echo e(ucfirst($admin->role)); ?></span></td>
                            </tr>
                            <tr>
                                <th>Created At</th>
                                <td><?php echo e($admin->created_at->format('d M Y, h:i A')); ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <a href="<?php echo e(route('admin.admin')); ?>" class="btn btn-secondary mt-3">Back to List</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\diamond_auction\resources\views/admin/admin/admin_details.blade.php ENDPATH**/ ?>