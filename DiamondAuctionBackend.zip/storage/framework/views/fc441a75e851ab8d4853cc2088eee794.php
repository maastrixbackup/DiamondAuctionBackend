<?php $__env->startSection('title', 'Edit Lot'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-lg-4 pt-lg-4">
        <div class="page-inner">
            <div class="page-header d-flex align-items-center justify-content-between flex-wrap mb-3">
                <div class="d-flex align-items-center gap-3">
                    <h3 class="fw-bold mb-0">Edit Lot</h3>
                    <ul class="breadcrumbs d-flex align-items-center mb-0">
                        <li class="nav-home me-2">
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <li class="separator me-2">
                            <i class="icon-arrow-right"></i>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.lots.index')); ?>">Lots</a>
                        </li>
                        <li class="separator"><i class="icon-arrow-right"></i></li>
                        <li class="nav-item"><a href="#">Edit Lot</a></li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Update Lot Information</div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.lots.update', $lot->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <!-- Column 1 -->
                                    <div class="col-md-6 col-lg-4">
                                        <div class="form-group">
                                            <label for="seller_id">Select Seller</label>
                                            <select name="seller_id" id="seller_id" class="form-control" required>
                                                <option value="">-- Select Seller --</option>
                                                <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($seller->id); ?>"
                                                        <?php echo e($lot->seller_id == $seller->id ? 'selected' : ''); ?>>
                                                        <?php echo e($seller->full_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="category_id">Select Category</label>
                                            <select name="category_id" id="category_id" class="form-control" required>
                                                <option value="">-- Select Category --</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"
                                                        <?php echo e($lot->category_id == $category->id ? 'selected' : ''); ?>>
                                                        <?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="type">Type</label>
                                            <input type="text" name="type" id="type" class="form-control"
                                                placeholder="Enter Type" value="<?php echo e($lot->type); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="color">Color</label>
                                            <input type="text" name="color" id="color" class="form-control"
                                                placeholder="Enter Color" value="<?php echo e($lot->color); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="weight">Weight</label>
                                            <input type="text" name="weight" id="weight" class="form-control"
                                                placeholder="Enter Weight" value="<?php echo e($lot->weight); ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="size">Size</label>
                                            <input type="text" name="size" id="size" class="form-control"
                                                placeholder="Enter Size" value="<?php echo e($lot->size); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select name="status" id="status" class="form-control">
                                                <option value="0" <?php echo e($lot->status == 0 ? 'selected' : ''); ?>>Pending
                                                </option>
                                                <option value="1" <?php echo e($lot->status == 1 ? 'selected' : ''); ?>>Active
                                                </option>
                                                <option value="2" <?php echo e($lot->status == 2 ? 'selected' : ''); ?>>Sold
                                                </option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Upload Images</label>
                                            <div id="image-upload-group">
                                                
                                                <?php if($lot->images && is_array($lot->images)): ?>
                                                    <?php $__currentLoopData = $lot->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="input-group mb-2">
                                                            <input type="file" name="images[]"
                                                                class="form-control image-input" accept="image/*">
                                                            <button type="button"
                                                                class="btn btn-sm btn-danger remove-image">-</button>
                                                        </div>
                                                        <div class="preview-group mb-2 d-flex flex-wrap gap-2">
                                                            <img src="<?php echo e(asset('storage/images/lots/' . $img)); ?>"
                                                                style="max-width: 100px; max-height: 100px;"
                                                                class="rounded border p-1">
                                                            <input type="hidden" name="existing_images[]"
                                                                value="<?php echo e($img); ?>">
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                                
                                                <div class="input-group mb-2">
                                                    <input type="file" name="images[]" class="form-control image-input"
                                                        accept="image/*">
                                                    <button type="button"
                                                        class="btn btn-sm btn-success add-more-image">+</button>
                                                </div>
                                                <div class="preview-group mb-2 d-flex flex-wrap gap-2"></div>
                                            </div>
                                        </div>



                                    </div>

                                    <!-- Column 2 -->
                                    <div class="col-md-6 col-lg-4">
                                        <div class="form-group">
                                            <label for="shape">Shape</label>
                                            <input type="text" name="shape" id="shape" class="form-control"
                                                placeholder="Enter Shape" value="<?php echo e($lot->shape); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="batch_code">Batch Code</label>
                                            <input type="text" name="batch_code" id="batch_code" class="form-control"
                                                placeholder="Enter Batch Code" value="<?php echo e($lot->batch_code); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="report_number">Report Number</label>
                                            <input type="text" name="report_number" id="report_number"
                                                class="form-control" placeholder="Enter Report Number"
                                                value="<?php echo e($lot->report_number); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="colour_grade">Colour Grade</label>
                                            <input type="text" name="colour_grade" id="colour_grade"
                                                class="form-control" placeholder="Enter Colour Grade"
                                                value="<?php echo e($lot->colour_grade); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="colour_origin">Colour Origin</label>
                                            <input type="text" name="colour_origin" id="colour_origin"
                                                class="form-control" placeholder="Enter Colour Origin"
                                                value="<?php echo e($lot->colour_origin); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="colour_distribution">Colour Distribution</label>
                                            <input type="text" name="colour_distribution" id="colour_distribution"
                                                class="form-control" placeholder="Enter Colour Distribution"
                                                value="<?php echo e($lot->colour_distribution); ?>">
                                        </div>
                                    </div>

                                    <!-- Column 3 -->
                                    <div class="col-md-6 col-lg-4">
                                        <div class="form-group">
                                            <label for="polish">Polish</label>
                                            <input type="text" name="polish" id="polish" class="form-control"
                                                placeholder="Enter Polish" value="<?php echo e($lot->polish); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="symmetry">Symmetry</label>
                                            <input type="text" name="symmetry" id="symmetry" class="form-control"
                                                placeholder="Enter Symmetry" value="<?php echo e($lot->symmetry); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="fluorescence">Fluorescence</label>
                                            <input type="text" name="fluorescence" id="fluorescence"
                                                class="form-control" placeholder="Enter Fluorescence"
                                                value="<?php echo e($lot->fluorescence); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="stone">Stone</label>
                                            <input type="text" name="stone" id="stone" class="form-control"
                                                placeholder="Enter Stone" value="<?php echo e($lot->stone); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="notes">Notes</label>
                                            <textarea name="notes" id="notes" rows="4" class="form-control" placeholder="Enter any notes..."><?php echo e($lot->notes); ?></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-action mt-4">
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <a href="<?php echo e(route('admin.lots.index')); ?>" class="btn btn-danger">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function createImagePreview(file, previewContainer) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.maxWidth = '100px';
                img.style.maxHeight = '100px';
                img.classList.add('rounded', 'border', 'p-1');
                previewContainer.innerHTML = '';
                previewContainer.appendChild(img);
            };
            reader.readAsDataURL(file);
        }

        function handleFileInput(input) {
            const previewContainer = input.closest('.input-group').nextElementSibling;
            previewContainer.innerHTML = '';
            Array.from(input.files).forEach(file => {
                if (file.type.startsWith('image/')) {
                    createImagePreview(file, previewContainer);
                }
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            const uploadGroup = document.getElementById('image-upload-group');

            uploadGroup.addEventListener('click', function(e) {
                if (e.target.classList.contains('add-more-image')) {
                    const inputGroup = document.createElement('div');
                    inputGroup.classList.add('input-group', 'mb-2');
                    inputGroup.innerHTML = `
                    <input type="file" name="images[]" class="form-control image-input" accept="image/*">
                    <button type="button" class="btn btn-sm btn-danger remove-image">-</button>
                `;

                    const previewGroup = document.createElement('div');
                    previewGroup.classList.add('preview-group', 'mb-2', 'd-flex', 'flex-wrap', 'gap-2');

                    uploadGroup.appendChild(inputGroup);
                    uploadGroup.appendChild(previewGroup);
                }

                if (e.target.classList.contains('remove-image')) {
                    const inputGroup = e.target.closest('.input-group');
                    const previewGroup = inputGroup.nextElementSibling;
                    inputGroup.remove();
                    if (previewGroup && previewGroup.classList.contains('preview-group')) {
                        previewGroup.remove();
                    }
                }
            });

            uploadGroup.addEventListener('change', function(e) {
                if (e.target.classList.contains('image-input')) {
                    handleFileInput(e.target);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\DiamondAuctionBackend\resources\views/admin/lots/edit.blade.php ENDPATH**/ ?>