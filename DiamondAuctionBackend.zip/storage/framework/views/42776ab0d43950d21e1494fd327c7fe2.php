<?php $__env->startSection('title', 'Bidder List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-lg-4 pt-lg-4">
        <div class="page-inner">
            <div class="page-header d-flex align-items-center justify-content-between flex-wrap mb-3">
                <div class="d-flex align-items-center gap-3">
                    <h3 class="fw-bold mb-0">Bidders</h3>
                    <ul class="breadcrumbs d-flex align-items-center mb-0">
                        <li class="nav-home me-2">
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <li class="separator me-2">
                            <i class="icon-arrow-right"></i>
                        </li>
                        <li class="nav-item">
                            <a href="#">Bidders</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h4 class="card-title mb-0">All Bidders</h4>
                        </div>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" id="success-alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Type</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>KYC Status</th>
                                            <th>Account Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $bidders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($bidder->type == 1 ? 'Company' : 'Individual'); ?></td>
                                                <td><?php echo e($bidder->full_name); ?></td>
                                                <td><?php echo e($bidder->email_address); ?></td>
                                                <td><?php echo e($bidder->phone_number); ?></td>

                                                <!-- KYC Status -->
                                                <td>
                                                    <span
                                                        class="badge badge-sm
        <?php echo e($bidder->kyc_status == 1 ? 'bg-success' : ($bidder->kyc_status == 2 ? 'bg-danger' : 'bg-warning')); ?>">
                                                        <?php echo e($bidder->kyc_status == 1 ? 'Approved' : ($bidder->kyc_status == 2 ? 'Rejected' : 'Pending')); ?>

                                                    </span>
                                                </td>


                                                <!-- Account Status -->
                                                <td>
                                                    <span
                                                        class="badge badge-sm
        <?php echo e($bidder->account_status == 1 ? 'bg-success' : ($bidder->account_status == 2 ? 'bg-danger' : 'bg-warning')); ?>">
                                                        <?php echo e($bidder->account_status == 1 ? 'Active' : ($bidder->account_status == 2 ? 'Suspended' : 'Pending')); ?>

                                                    </span>
                                                </td>

                                                <!-- View Action -->
                                                <td>
                                                    <a href="<?php echo e(route('admin.bidderDetails', $bidder->id)); ?>"
                                                        class="btn btn-sm btn-primary" title="View">
                                                        <i class="icon-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.onload = function() {
            let alert = document.getElementById('success-alert');
            if (alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                }, 3000);
            }
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\DiamondAuctionBackend\resources\views/admin/bidder/bidder_list.blade.php ENDPATH**/ ?>