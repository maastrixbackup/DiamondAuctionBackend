

<form id="updateSlotForm">
    <div id="successMessage" class="alert alert-success d-none" role="alert"></div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Lot ID</th>
                <th>Bidder Name</th>
                <th>Room Name</th>
                <th>Room Type</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="lot-row-<?php echo e($lot->id); ?>">
                    <td><?php echo e($lot->lot_id); ?></td>
                    <td><?php echo e($lot->bidder_name); ?></td>
                    <td><?php echo e($lot->room_name); ?></td>
                    <td><?php echo e($lot->room_type); ?></td>
                    <td><?php echo e($lot->date_for_reservation); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($lot->start_time)->format('h:i A')); ?></td>
                    <td>
                        <?php if($lot->status == 0): ?>
                            <span class="badge bg-warning">Pending</span>
                        <?php elseif($lot->status == 1): ?>
                            <span class="badge bg-success">Approved</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Rejected</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($lot->status == 0): ?>
                            <select name="lot_status[<?php echo e($lot->id); ?>]" class="form-select form-select-sm">
                                <option value="">-- Select --</option>
                                <option value="1">Approve</option>
                                <option value="2">Reject</option>
                            </select>
                        <?php else: ?>
                            <span class="text-muted"></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <div class="text-end mt-3">
        <button type="button" class="btn btn-primary" onclick="submitLotStatuses()">Update Slot</button>
    </div>
</form>
<?php /**PATH F:\DiamondAuctionBackend\resources\views/admin/lots/viewRequestLots.blade.php ENDPATH**/ ?>